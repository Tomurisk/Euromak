#!/bin/bash

# Path variables
state_file="$HOME/.layout/state"
lt_layout="$HOME/.layout/LTlayout"
ro_layout="$HOME/.layout/ROlayout"
xcompose_file="$HOME/.XCompose"

# Check if state file contains "RO"
if grep -q "RO" "$state_file"; then
    # Output LT layout to .XCompose
    cat "$lt_layout" > "$xcompose_file"
    
    # Change state to "LT"
    echo "LT" > "$state_file"
    
    # Reload input
    ibus restart
else
    # Output RO layout to .XCompose
    cat "$ro_layout" > "$xcompose_file"
    
    # Change state to "RO"
    echo "RO" > "$state_file"

    # Reload input
    ibus restart
fi

exit 0